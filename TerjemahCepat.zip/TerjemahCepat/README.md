# Terjemah Cepat

Tombol mengambang yang saat diketuk menekan lama indikator navigasi (membuka Circle to Search), lalu menekan tombol Terjemahkan di dalamnya.

## Build APK

**Android Studio (PC):** File > Open > pilih folder ini > tunggu sync > Build > Build APK(s).
Hasil: `app/build/outputs/apk/debug/app-debug.apk`

**Tanpa PC (GitHub Actions):** upload isi folder ini ke repo GitHub baru, buka tab Actions > Build APK > Run workflow, lalu unduh artifact `TerjemahCepat-apk`.

**Terminal:** `./gradlew assembleDebug` (butuh JDK 17 dan Android SDK 34).

## Pasang

1. Pasang APK, buka aplikasinya.
2. Info Aplikasi > titik tiga kanan atas > Izinkan setelan terbatas.
3. Aktifkan Terjemah Cepat di Aksesibilitas.
4. Hemat baterai > Tanpa batasan, dan Autostart aktif, supaya tidak dimatikan HyperOS.

## Jika Circle to Search tidak muncul

Ubah di layar utama aplikasi: durasi tekan lama (coba 600 sampai 1200 ms) dan jarak dari tepi bawah (coba 4 sampai 20 dp).
