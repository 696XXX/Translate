package com.azam.terjemahcepat

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var status: TextView
    private var density = 1f

    private fun dp(v: Int) = (v * density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences(TranslateService.PREFS, MODE_PRIVATE)
        density = resources.displayMetrics.density

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(28), dp(20), dp(28))
        }

        root.addView(text("Terjemah Cepat", 26f, bold = true))

        status = text("", 15f, bold = true)
        status.setPadding(0, dp(8), 0, dp(12))
        root.addView(status)

        root.addView(
            text(
                "Cara pakai:\n" +
                    "1. Tekan \"Info Aplikasi\", titik tiga di kanan atas, lalu \"Izinkan setelan terbatas\" (wajib untuk aplikasi di luar Play Store).\n" +
                    "2. Tekan \"Aktifkan Aksesibilitas\", pilih Terjemah Cepat, nyalakan.\n" +
                    "3. Tombol biru muncul di layar. Ketuk untuk menerjemahkan layar, tahan lalu geser untuk memindahkan.",
                14f
            )
        )

        root.addView(button("Info Aplikasi") {
            safeStart(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
            )
        })
        root.addView(button("Aktifkan Aksesibilitas") {
            safeStart(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })

        root.addView(spacer(16))

        val sw = Switch(this).apply {
            text = "Tampilkan tombol mengambang"
            textSize = 15f
            isChecked = prefs.getBoolean(TranslateService.KEY_SHOW, true)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean(TranslateService.KEY_SHOW, checked).apply()
            }
        }
        root.addView(sw)

        val fb = Switch(this).apply {
            text = "Cadangan: ketuk koordinat jika tombol tidak terbaca"
            textSize = 15f
            isChecked = prefs.getBoolean(TranslateService.KEY_FALLBACK, true)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean(TranslateService.KEY_FALLBACK, checked).apply()
            }
        }
        fb.setPadding(0, dp(12), 0, dp(4))
        root.addView(fb)

        root.addView(spacer(12))
        root.addView(text("Kalibrasi (ubah jika Circle to Search tidak muncul)", 14f, bold = true))

        addSeek(
            root, "Durasi tekan lama", TranslateService.KEY_HOLD_MS,
            min = 400, max = 1600, step = 50, def = TranslateService.DEF_HOLD_MS, unit = " ms"
        )
        addSeek(
            root, "Jarak tekan dari tepi bawah", TranslateService.KEY_BOTTOM_DP,
            min = 2, max = 30, step = 1, def = TranslateService.DEF_BOTTOM_DP, unit = " dp"
        )

        root.addView(spacer(16))
        root.addView(
            text(
                "Agar layanan tidak dimatikan sistem: Info Aplikasi, Hemat baterai, pilih \"Tanpa batasan\", dan aktifkan Autostart.",
                13f
            )
        )
        root.addView(button("Buka Autostart (Xiaomi/Poco)") {
            safeStart(
                Intent().setComponent(
                    ComponentName(
                        "com.miui.securitycenter",
                        "com.miui.permcenter.autostart.AutoStartManagementActivity"
                    )
                )
            )
        })

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }

    private fun updateStatus() {
        if (isServiceEnabled()) {
            status.text = "Layanan AKTIF"
            status.setTextColor(Color.parseColor("#188038"))
        } else {
            status.text = "Layanan belum aktif"
            status.setTextColor(Color.parseColor("#D93025"))
        }
    }

    private fun isServiceEnabled(): Boolean {
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabled.split(':').any { it.startsWith("$packageName/") }
    }

    private fun safeStart(intent: Intent) {
        try {
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "Tidak bisa membuka halaman ini di HP kamu.", Toast.LENGTH_LONG).show()
        }
    }

    // ---------------------------------------------------------------- helper UI

    private fun text(s: String, sizeSp: Float, bold: Boolean = false) = TextView(this).apply {
        text = s
        textSize = sizeSp
        setTextColor(Color.parseColor("#202124"))
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        setPadding(0, dp(4), 0, dp(4))
    }

    private fun button(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(8) }
    }

    private fun spacer(h: Int) = android.view.View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(h))
    }

    private fun addSeek(
        root: LinearLayout, label: String, key: String,
        min: Int, max: Int, step: Int, def: Int, unit: String
    ) {
        val current = prefs.getInt(key, def).coerceIn(min, max)
        val caption = text("$label: $current$unit", 14f)
        caption.gravity = Gravity.START
        val bar = SeekBar(this).apply {
            this.max = (max - min) / step
            progress = (current - min) / step
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    val value = min + p * step
                    caption.text = "$label: $value$unit"
                    if (fromUser) prefs.edit().putInt(key, value).apply()
                }

                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        root.addView(caption)
        root.addView(bar)
    }
}
