package com.azam.terjemahcepat

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.ImageView
import android.widget.Toast
import kotlin.math.abs

/**
 * Menampilkan tombol mengambang. Saat diketuk:
 * 1. tombol disembunyikan sebentar (supaya tidak ikut ter-screenshot),
 * 2. menekan lama indikator navigasi di bawah layar (memicu Circle to Search),
 * 3. mencari tombol "Terjemahkan" di jendela Google lalu menekannya.
 */
class TranslateService : AccessibilityService() {

    companion object {
        const val PREFS = "prefs"
        const val KEY_SHOW = "show_button"
        const val KEY_HOLD_MS = "hold_ms"
        const val KEY_BOTTOM_DP = "bottom_dp"
        const val KEY_FALLBACK = "fallback_tap"
        const val KEY_POS_X = "pos_x"
        const val KEY_POS_Y = "pos_y"

        const val DEF_HOLD_MS = 800
        const val DEF_BOTTOM_DP = 8

        private const val GOOGLE_PKG = "com.google.android.googlequicksearchbox"
        private val KEYWORDS = listOf("terjemah", "translate")

        // Posisi ikon terjemah di bilah Circle to Search, diukur dari screenshot 1080x2400.
        private const val FALLBACK_X = 0.871f
        private const val FALLBACK_Y = 0.918f
    }

    private val wm: WindowManager by lazy { getSystemService(WINDOW_SERVICE) as WindowManager }
    private val prefs: SharedPreferences by lazy { getSharedPreferences(PREFS, MODE_PRIVATE) }
    private val handler = Handler(Looper.getMainLooper())

    private var button: ImageView? = null
    private var busy = false
    private var googleSeen = false

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == KEY_SHOW) applyVisibility()
    }

    // ---------------------------------------------------------------- lifecycle

    override fun onServiceConnected() {
        super.onServiceConnected()
        prefs.registerOnSharedPreferenceChangeListener(prefListener)
        applyVisibility()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (busy && event?.packageName?.toString() == GOOGLE_PKG) googleSeen = true
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        prefs.unregisterOnSharedPreferenceChangeListener(prefListener)
        removeButton()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- tombol mengambang

    private fun applyVisibility() {
        if (prefs.getBoolean(KEY_SHOW, true)) addButton() else removeButton()
    }

    private fun addButton() {
        if (button != null) return

        val d = resources.displayMetrics.density
        val size = (52 * d).toInt()
        val pad = (13 * d).toInt()
        val slop = ViewConfiguration.get(this).scaledTouchSlop

        val iv = ImageView(this)
        iv.setImageResource(R.drawable.ic_translate)
        iv.setPadding(pad, pad, pad, pad)
        iv.elevation = 6 * d
        iv.contentDescription = "Tombol terjemah mengambang"
        iv.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.parseColor("#E61A73E8"))
        }

        val (sw, sh) = screenSize()
        val lp = WindowManager.LayoutParams(
            size,
            size,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = prefs.getInt(KEY_POS_X, sw - size - (8 * d).toInt()).coerceIn(0, maxOf(0, sw - size))
        lp.y = prefs.getInt(KEY_POS_Y, sh / 2).coerceIn(0, maxOf(0, sh - size))

        iv.setOnTouchListener(object : View.OnTouchListener {
            private var downX = 0f
            private var downY = 0f
            private var startX = 0
            private var startY = 0
            private var moved = false

            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = e.rawX
                        downY = e.rawY
                        startX = lp.x
                        startY = lp.y
                        moved = false
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = e.rawX - downX
                        val dy = e.rawY - downY
                        if (!moved && (abs(dx) > slop || abs(dy) > slop)) moved = true
                        if (moved) {
                            val (w, h) = screenSize()
                            lp.x = (startX + dx).toInt().coerceIn(0, maxOf(0, w - lp.width))
                            lp.y = (startY + dy).toInt().coerceIn(0, maxOf(0, h - lp.height))
                            try {
                                wm.updateViewLayout(v, lp)
                            } catch (e: Exception) {
                            }
                        }
                    }
                    MotionEvent.ACTION_UP -> {
                        if (moved) {
                            prefs.edit().putInt(KEY_POS_X, lp.x).putInt(KEY_POS_Y, lp.y).apply()
                        } else {
                            onButtonTapped()
                        }
                    }
                }
                return true
            }
        })

        try {
            wm.addView(iv, lp)
            button = iv
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal menampilkan tombol: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun removeButton() {
        val b = button ?: return
        try {
            wm.removeView(b)
        } catch (e: Exception) {
        }
        button = null
    }

    @Suppress("DEPRECATION")
    private fun screenSize(): Pair<Int, Int> {
        val dm = getSystemService(DISPLAY_SERVICE) as DisplayManager
        val m = DisplayMetrics()
        dm.getDisplay(Display.DEFAULT_DISPLAY).getRealMetrics(m)
        return Pair(m.widthPixels, m.heightPixels)
    }

    // ---------------------------------------------------------------- alur utama

    private fun onButtonTapped() {
        if (busy) return
        busy = true
        googleSeen = false
        button?.visibility = View.INVISIBLE // supaya tombol tidak ikut ter-screenshot
        handler.postDelayed({ startLongPress() }, 150)
    }

    private fun startLongPress() {
        val (sw, sh) = screenSize()
        val d = resources.displayMetrics.density
        val bottomPx = prefs.getInt(KEY_BOTTOM_DP, DEF_BOTTOM_DP) * d
        val hold = prefs.getInt(KEY_HOLD_MS, DEF_HOLD_MS).toLong()

        val path = Path()
        path.moveTo(sw / 2f, sh - bottomPx)
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, hold))
            .build()

        val sent = dispatchGesture(
            gesture,
            object : AccessibilityService.GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    waitForCircleToSearch()
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    // Sistem sering membatalkan gestur begitu Circle to Search terbuka; tetap lanjut.
                    waitForCircleToSearch()
                }
            },
            null
        )
        if (!sent) finish("Gagal mengirim gestur tekan lama.")
    }

    private fun waitForCircleToSearch() {
        val start = System.currentTimeMillis()
        val poller = object : Runnable {
            override fun run() {
                val elapsed = System.currentTimeMillis() - start
                val googleOpen = googleSeen || hasGoogleWindow()

                if (googleOpen) {
                    val node = findTranslateNode()
                    if (node != null) {
                        clickNode(node)
                        restoreWhenClosed()
                        return
                    }
                    if (elapsed > 2500 && prefs.getBoolean(KEY_FALLBACK, true)) {
                        tapFallback()
                        restoreWhenClosed()
                        return
                    }
                }

                if (elapsed > 4500) {
                    if (googleOpen) {
                        finish("Tombol Terjemahkan tidak ditemukan.")
                    } else {
                        finish("Circle to Search tidak muncul. Coba ubah durasi/posisi tekan lama di aplikasi.")
                    }
                    return
                }
                handler.postDelayed(this, 200)
            }
        }
        handler.postDelayed(poller, 250)
    }

    private fun restoreWhenClosed() {
        var tries = 0
        val r = object : Runnable {
            override fun run() {
                tries++
                if (tries > 40 || !hasGoogleWindow()) {
                    done()
                } else {
                    handler.postDelayed(this, 500)
                }
            }
        }
        handler.postDelayed(r, 1200)
    }

    private fun finish(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
        done()
    }

    private fun done() {
        button?.visibility = View.VISIBLE
        busy = false
    }

    // ---------------------------------------------------------------- pencarian node & klik

    private fun hasGoogleWindow(): Boolean = try {
        windows.any { it.root?.packageName?.toString() == GOOGLE_PKG }
    } catch (e: Exception) {
        false
    }

    private fun findTranslateNode(): AccessibilityNodeInfo? {
        val roots = try {
            windows.mapNotNull { it.root }
        } catch (e: Exception) {
            emptyList()
        }
        for (root in roots) {
            if (root.packageName?.toString() != GOOGLE_PKG) continue
            val hit = search(root, 0)
            if (hit != null) return hit
        }
        return null
    }

    private fun search(node: AccessibilityNodeInfo?, depth: Int): AccessibilityNodeInfo? {
        if (node == null || depth > 25) return null
        val label = listOf(node.contentDescription, node.text, node.viewIdResourceName)
            .joinToString(" ") { it?.toString().orEmpty() }
            .lowercase()
        if (KEYWORDS.any { label.contains(it) }) return node
        for (i in 0 until node.childCount) {
            val hit = search(node.getChild(i), depth + 1)
            if (hit != null) return hit
        }
        return null
    }

    private fun clickNode(node: AccessibilityNodeInfo) {
        var n: AccessibilityNodeInfo? = node
        var depth = 0
        while (n != null && depth < 6) {
            if (n.isClickable && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return
            n = n.parent
            depth++
        }
        val r = Rect()
        node.getBoundsInScreen(r)
        if (!r.isEmpty) tap(r.centerX().toFloat(), r.centerY().toFloat()) else tapFallback()
    }

    private fun tap(x: Float, y: Float) {
        val path = Path()
        path.moveTo(x, y)
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 60))
            .build()
        dispatchGesture(g, null, null)
    }

    private fun tapFallback() {
        val (sw, sh) = screenSize()
        tap(sw * FALLBACK_X, sh * FALLBACK_Y)
    }
}
